// just to avoid a warning...
import PropTypes from 'prop-types'

window.PropTypes = PropTypes
