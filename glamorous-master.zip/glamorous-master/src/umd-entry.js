/* istanbul ignore next */
import glamorous from './cjs-entry'

export default glamorous
