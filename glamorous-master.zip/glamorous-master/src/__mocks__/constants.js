module.exports = {
  CHANNEL: '__glamorous__',
  isPreact: Boolean(process.env.MOCK_PREACT),
}
